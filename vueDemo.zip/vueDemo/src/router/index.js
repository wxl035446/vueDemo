import Vue from 'vue'
import Router from 'vue-router'


Vue.use(Router)

 const router =  new Router({
  routes: [
     {
       path: '/demo',
       name: 'demo',
       component: resolve => {
         require.ensure(['../views/demo.vue'], () => {
           resolve(require('../views/demo.vue'));
         });
       },
        // meta: {
        //   keepAlive: false // 不需要缓存
        // }
     },
    //按需加载安全键盘
    {
      path: '/keyBoard',
      name: 'keyBoard',
       component: resolve => {
         require.ensure(['../components/keyBoard.vue'], () => {
           resolve(require('../components/keyBoard.vue'));
         });
       },
        meta: {
          keepAlive: true // 需要被缓存
        }
    },
    //按需加载安全键盘
    {
      path: '/keepAliveA',
      name: 'keepAliveA',
      component: resolve => {
        require.ensure(['../views/keepAliveA.vue'], () => {
          resolve(require('../views/keepAliveA.vue'));
        });
      },
    },
       //按需加载安全键盘
       {
         path: '/keepAliveB',
         name: 'keepAliveB',
         component: resolve => {
           require.ensure(['../views/keepAliveB.vue'], () => {
             resolve(require('../views/keepAliveB.vue'));
           });
         },
      //  meta: {
      //    keepAlive: true // 需要被缓存
      //  }
    },
     {
       path: '/pickerDate',
       name: 'pickerDate',
       component: resolve => {
         require.ensure(['../components/pickerDate.vue'], () => {
           resolve(require('../components/pickerDate.vue'));
         });
       },
     }
    ],
  //保持原先的滚动值
  scrollBehavior (to, from, savedPosition) {
    if (savedPosition) {
      return savedPosition
    } else {
      const position = {}
      //滚动到锚点
      if (to.hash) {
        position.selector = to.hash
      }
      // 如果meta中有scrollTop
      if (to.matched.some(m => m.meta.scrollToTop)) {
        position.x = 0
        position.y = 0
      }
      //所有路由导航， 简单地让页面滚动到顶部
      return position

      //跟keepAlive结合
      // if (from.meta.keepAlive) {
      // from.meta.savedPosition = document.body.scrollTop;
      // }
      // return {
      //   x: 0,
      //   y: to.meta.savedPosition || 0
      // }

     }
  }
})

export default router
