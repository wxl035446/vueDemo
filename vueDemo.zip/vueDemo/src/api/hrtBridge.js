/*
 * 与APP交互内容 jsbridge
 * zhaojuan
 * 2018-03-05
 ************************************************/
/**
 * 函数描述：js调用webview事件
 *
 * jsBridge.callHandler(method, data, callBack(response));
 * @param method {string} 方法名
 * @param data {Object} 参数
 * @return {Object} 回调
 */

/**
 * 函数描述：webView调用JS事件
 *
 * jsBridge.registerHandler(method, callBack(response));
 * @param method {string} 方法名
 * @return {Object} 回调
 */


var setupWebViewJavascriptBridge = function () {};
var isIOS = /\b(iPad|iPhone|iPod)(?=;)/.test(navigator.userAgent);
// 安卓JSbridge
if (!isIOS) {
  setupWebViewJavascriptBridge = function setupWebViewJavascriptBridge(callback) {
    if (window.WebViewJavascriptBridge) {
      callback(WebViewJavascriptBridge)
    } else {
      document.addEventListener(
        '__WebViewJavascriptBridgeReady__',
        function () {
          callback(WebViewJavascriptBridge)
        },
        false
      );
    }
  }
  // 安卓特殊处理
  setupWebViewJavascriptBridge(function (bridge) {
    // 注册以下函数，不然回调方法不会被调用
    bridge.init(function (message, responseCallback) {
      responseCallback();
    });
  });
} else { // IOS JSbridge
  setupWebViewJavascriptBridge = function setupWebViewJavascriptBridge(callback) {
    if (window.WebViewJavascriptBridge) {
      return callback(WebViewJavascriptBridge);
    }
    if (window.WVJBCallbacks) {
      return window.WVJBCallbacks.push(callback);
    }
    window.WVJBCallbacks = [callback];
    var WVJBIframe = document.createElement('iframe');
    WVJBIframe.style.display = 'none';
    WVJBIframe.src = 'wvjbscheme://__BRIDGE_LOADED__';
    document.documentElement.appendChild(WVJBIframe);
    setTimeout(function () {
      document.documentElement.removeChild(WVJBIframe)
    }, 300);
  }
}

var hrt = {
  /*init: function(callback) {
      var isIOS = /\b(iPad|iPhone|iPod)(?=;)/.test(navigator.userAgent);
      if (!isIOS) {
          if (window.WebViewJavascriptBridge) {
              callback(WebViewJavascriptBridge)
          } else {
              document.addEventListener(
                  'WebViewJavascriptBridgeReady',
                  function() {
                      callback(WebViewJavascriptBridge)
                  },
                  false
              );
          }
      } else {
          if (window.WebViewJavascriptBridge) {
              return callback(WebViewJavascriptBridge);
          }
          if (window.WVJBCallbacks) {
              return window.WVJBCallbacks.push(callback);
          }
          window.WVJBCallbacks = [callback];
          var WVJBIframe = document.createElement('iframe');
          WVJBIframe.style.display = 'none';
          WVJBIframe.src = 'wvjbscheme://__BRIDGE_LOADED__';
          document.documentElement.appendChild(WVJBIframe);
          setTimeout(function() {
              document.documentElement.removeChild(WVJBIframe)
          }, 0)
      }
  },

  ready: function() {
      var isIOS = /\b(iPad|iPhone|iPod)(?=;)/.test(navigator.userAgent);
      if (!isIOS) {
          var _this = this;
          _this.init(function(bridge) {
              bridge.init(function(message, responseCallback) {
                  responseCallback();
              })
          })
      }
  },

  registerHandler: function(name, fun) {
      var _this = this;
      _this.init(function(bridge) {
          bridge.registerHandler(name, fun);
      })
  },*/

  callHandler: function (name, data, fun) {
    var isHrt = navigator.userAgent.match(/hrtbrowser/);
    var isRx = navigator.userAgent.match(/rxbrowser/);
    if (!isHrt && !isRx) {
      console.log("calling native method " + name + "......")
    }
    setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler(name, data, fun);
    })
  },

  //拉起原生密码安全键盘
  popInputPwd: function (options) {

    var _this = this;
    _this.callHandler('popInputPwd', options, function (res) {
      res = (typeof res === 'string') ? JSON.parse(res) : res;
      if (res.code == 0) {
        options.success && options.success(res.data);
      } else {
        options.fail && options.fail(res);
      }
      options.complete && options.complete();
    });
  },

  //活体识别
  detect: function (options) {
    var _this = this;
    _this.callHandler('detect', options, function (res) {
      res = (typeof res === 'string') ? JSON.parse(res) : res;
      if (res.code == 0) {
        options.success && options.success(res.data);
      } else {
        options.fail && options.fail(res);
      }
      options.complete && options.complete();
    });
  },
  /*
   * 控制webview展示内容
   * showBackBtn true 显示 false 不显示
   * showRightBtn true 显示 false 不显示
   * rightBtnTitle ''默认不显示 有文字就显示内容
   */
  showControls: function (options) {
    var _this = this;
    if (!options.hasOwnProperty('showRightBtn')) {
      options.showRightBtn = !!options.rightBtnTitle;
    }
    _this.callHandler('showNaviControl', options, function () {});
  },

  //获取用户登录信息
  getUserInfo: function (options) {
    var _this = this;
    _this.callHandler('getUserInfo', options, function (res) {
      res = (typeof res === 'string') ? JSON.parse(res) : res;
      if (res.code == 0) {
        options.success && options.success(res.data);
      } else {
        options.fail && options.fail(res);
      }
      options.complete && options.complete();
    });
  },
  // 拉起登录
  goLogin: function (options) {
    var _this = this;
    _this.callHandler('goLogin', options, function (res) {
      res = (typeof res === 'string') ? JSON.parse(res) : res;
      if (res.code === 0) {
        options.success && options.success(res.data);
      }
    });
  },
  /*
   * 关闭加载WebView的页面
   * wxl
   * 2018-7-9
   **/
  closePage: function (options) {
    var _this = this;
    _this.callHandler('exitWebPage', {}, function (res) {
      res = (typeof res === 'string') ? JSON.parse(res) : res;
      if (res.code === 0) {
        options.success && options.success(res.data);
      }
    });
  }

}

export {
  hrt
};