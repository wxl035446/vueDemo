import axios from 'axios';
import uuid from 'uuid';
import { getHrtAttr } from './api';

const instance = axios.create({
    baseURL:'',
    timeout: 15000,  //请求超时的毫秒数
    withCredentials: true,   //跨域请求时是否需要使用凭证
    headers: {"Content-Type": "application/json;charset=utf-8"}
})

let server;
let SUCCESS = 'S0A00000';
let LOGOUT = 'E1B00002';
let NETERROR = '网络异常，请检查网络设置';

let appId;
let secret;
let pubKey;
let env = process.env.NODE_ENV;

if(process.env.NODE_ENV === 'dev') {
  //server = 'https://sit99jr.huaruntong.cn/openapi/rs-service/' //186环境
  //server = 'https://sit99jr.huaruntong.cn/openapi/rs-service/?env=b1sit'  //185环境
  server = 'https://sit99jr.huaruntong.cn/openapi/rs-service/?env=dev'
} else if (process.env.NODE_ENV === 'uat') {
  server = 'https://uat99login.huaruntong.cn:10001/openapi/rs-service/'
} else if(process.env.NODE_ENV === 'prd') {
  server = 'https://app.huaruntong.cn/openapi/rs-service/';
} else {
  server = 'https://sit99jr.huaruntong.cn/openapi/rs-service/' //186环境
}



export function ajax (options) {
    
let userToken = '';
    if(process.env.NODE_ENV === 'dev'){
      userToken = '421ca17b3b9ec374f1e989b8b27d5540';
    }
     options.data = options.data || {};
    if(options.data.data) {
      options.data.data.memberToken = localStorage.getItem("token") || userToken;
      options.data.orgCode = options.data.orgCode || 'T0000000';
      options.data.storeCode = options.data.storeCode || '15';
    }else{
      options.data.token =  localStorage.getItem("token") || userToken;
    }
    options.data.sysId = options.data.sysId || 'T0000001';
    options.data.merchantCode = options.data.merchantCode || '1999000000001';
    options.data.channelId = options.data.channelId || 'APP';
    options.data.transactionUuid = options.data.transactionUuid || uuid.v4().replace(/-/g, '');
    return new Promise( (resolve,reject) => {
      console.log(reject)
      axios({
            method: 'post',
            url: server,
            data: {
                REQUEST: {
                  HRT_ATTRS: getHrtAttr(options),
                  REQUEST_DATA: options.data
              }
          }
      }).then( response => {
      let data = response.data;
      if (data.RESPONSE && data.RESPONSE.RETURN_CODE === SUCCESS) {
        resolve(data.RESPONSE.RETURN_DATA);
      } else if (data.RESPONSE && data.RESPONSE.RETURN_CODE === LOGOUT){
        this.toast && this.toast('请重新登陆后再试！');
        reject('logout');
      } else{
        if (data.RESPONSE) {
            this.toast && this.toast(data.RESPONSE.RETURN_DESC+"("+data.RESPONSE.RETURN_CODE+")");
        } else {
          this.toast && this.toast(NETERROR);
        }
        reject(data.RESPONSE);
      }
      }).catch(err => {
        this.toast && this.toast(NETERROR);
        reject(err)
      })
})
};
