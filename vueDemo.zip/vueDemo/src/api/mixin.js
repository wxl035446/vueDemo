/*
 * @Description: created by wxl
 * @Author: wxl
 * @Date: 2018-12-28 14:03:55
 * @LastEditTime: 2018-12-28 14:36:08
 */
//公共方法提取
import {ajax} from './ajax';
export default {
   methods:{
    ajax(options) {
      this.$store.commit('setLoadingShow', true);
      return ajax.call(this, options).then(res => {
        this.$store.commit('setLoadingShow', false);
        return Promise.resolve(res);
      }, err => {
        this.$store.commit('setLoadingShow', false);
        if (err === 'logout') {
          if (this.$store.state.entrance == 'wx') {
            let kadai = {
              sit: "https://sit99jr.huaruntong.cn/kadai/#/login",
              dev: "http://10.52.10.155:8080/assets/#/login",
              uat: "https://uat99jr.huaruntong.cn:1128/kadai/#/login",
              prd: "https://jr.huaruntong.cn/kadai/#/login",
            }
            window.location.replace(kadai[process.env.NODE_ENV]);
          } else {
            hrt.goLogin({
              isBackRoot: true,
              success: function (data) {
                location.reload();
              }
            });
          }
        }
        return Promise.reject(err);
      });
    },
    /*
     * 获取URL参数
     * @param {string} key
     * @param {string} str 如果指定的话从该字符串获取
     * @return {string}
     **/
    getURLParam(key, str) {
      var r = new RegExp('\\?(?:.+&)?' + key + '=(.*?)(?:&.*)?$');
      var m = (str || window.location.toString()).match(r);
      return m ? m[1] : ""; //如果需要处理中文，可以用返回decodeURLComponent(m[1])
    },
    /**
     * toast提示框
     * @param message {String} 提示框文案
     */
    toast(message) {
      return Toast({
        message,
        duration: 2500
      });
    },
    /**
     * alert提示框
     * @param message {String} 提示框文案
     * @param confirmButtonText {String} 按钮文案
     */
    alert(message, confirmButtonText = '我知道了') {
      return MessageBox({
        message,
        confirmButtonText,
        confirmButtonClass: 'btn-mint-comfirm'
      });
    },

    /**
     * confirm确认框
     * @param message {String} 确认框文案
     */
    confirm(message) {
      return MessageBox({
        message,
        showCancelButton: true
      });
    },
    // 手机 姓名 电话 身份证 验证方法规则
    // 验证是否为空func
    isCheckEmpty(tip, value) {
      let flag = true;
      if (!value) {
        flag = false;
        this.toast(tip);
      }
      return flag;
    },
    // 只能输入数字
    isCheckNumber(tip, value) {
      let reg = /^\+?[0-9][0-9]*$/;
      let flag = true;
      if (!reg.test(value)) {
        flag = false;
        this.toast(tip);
      }
      return flag;
    },
    // 验证正确的姓名格式
    isCheckName(tip, name) {
      let reg = /^[\u4e00-\u9fa5a-zA-Z]+$/;
      let flag = true;
      if (!reg.test(name)) {
        flag = false;
        this.toast(tip);
      }
      return flag;
    },
    // 验证是否为电话号码
    isCheckPhone(tip, number) {
      let validateJson = {
        "Phone": {
          "reg": "^0?(1[3-9])[0-9]{9}$",
          "tip": "输入合法手机号码"
        }
      };
      let isMobile = new RegExp(validateJson.Phone.reg);
      let flag = true;
      if (!isMobile.test(number)) {
        flag = false;
        this.toast(tip);
      }
      return flag;
    },
    // 验证身份证格式
    isCheckCardId(tip, str) {
      let reg = /(^[1-9]\d{5}(18|19|([23]\d))\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$)|(^[1-9]\d{5}\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{2}$)/;
      let flag = true;
      if (!reg.test(str)) {
        flag = false;
        this.toast(tip);
      }
      return flag;
    },
    // 验证银行卡格
    isCheckBankCard(tip, str) {
      var reg = /\d{15}|\d{19}/;
      let flag = true;
      if (!reg.test(str)) {
        flag = false;
        this.toast(tip);
      }
      return flag;
    },
    /**
     * 时间格式化
     */
    dateFormat(date, fmt = 'yyyy-MM-dd') {
      if (date === '' || date == undefined) {
        return '';
      }
      var that = new Date(date);
      var o = {
        "M+": that.getMonth() + 1, //月份
        "d+": that.getDate(), //日
        "h+": that.getHours(), //小时
        "m+": that.getMinutes(), //分
        "s+": that.getSeconds(), //秒
        "q+": Math.floor((that.getMonth() + 3) / 3), //季度
        "S": that.getMilliseconds() //毫秒
      };
      if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (that.getFullYear() + "").substr(4 - RegExp.$1.length));
      for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
      return fmt;
    },
    //判断是否是微信浏览器的函数
    isWeiXin() {
      //window.navigator.userAgent属性包含了浏览器类型、版本、操作系统类型、浏览器引擎类型等信息，这个属性可以用来判断浏览器类型
      var ua = window.navigator.userAgent.toLowerCase();
      //通过正则表达式匹配ua中是否含有MicroMessenger字符串
      if (ua.match(/MicroMessenger/i) == 'micromessenger') {
        return true;
      } else {
        return false;
      }
    }
  }
}