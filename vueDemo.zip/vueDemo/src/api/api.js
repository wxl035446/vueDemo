import md5 from 'md5';

export function getHrtAttr(options) {
  //var tzoffset = (new Date()).getTimezoneOffset() * 60000; //offset in milliseconds
  var tzoffset = -480 * 60000; //强制使用东八区
  var localISOTime = (new Date(Date.now() - tzoffset)).toISOString();
  var token = '';
  var secret = '';
  let data;

    if(process.env.NODE_ENV === 'prd') {
      token = '81e2c8c9e12c4334861ac9927b3c37e1';
      secret = 'bcf6800912b842bb81e6215b93de8312';
    } else if(process.env.NODE_ENV === 'uat') {
      token = '81e2c8c9e12c4334861ac9927b3c37e1';
      secret = 'bcf6800912b842bb81e6215b93de8312';
    } else {
      token = '81e2c8c9e12c4334861ac9927b3c37e1';
      secret = 'bcf6800912b842bb81e6215b93de8312';
    }
    data = {
      App_Token: token,
      Api_ID: options.apiId,
      Api_Version: options.apiVersion || '2.0.0',
      Time_Stamp: localISOTime.slice(0, 23).replace('T', ' ').replace('.', ':'),
      Sign_Method: 'md5',
      Format: 'json',
      Partner_ID: 'T0000000',
      Sys_ID: 'T0000001',
      App_Sub_ID: 'T000000102FX',
      App_Pub_ID: '',
      REQUEST_DATA: JSON.stringify(options.data)
    };
  
  var str = '';
  Object.keys(data).sort().forEach(key => str += `${key}=${data[key]}&`);
  str += secret;

  delete data.REQUEST_DATA;

  data.Sign = md5(str).toUpperCase();

  return data;
}
