<template>
  <div class="yb-wrapper">
    <ul class="yb-ul">
      <li class="yb-li ln-border-b" v-for="(item,index ) in list" :key="index" @click="goIntoPage(item)" >{{item.name}}</li>
    </ul>
  </div>
</template>
<script>
export default{
  data(){
    return{
     list:[{name:'keepAlive',query:{}},{name:'keyBoard',query:{payPwdProcFlag:'VERIFYPWD'}}]
    }

  },
  created(){
   var result= this.bbao()
   result.forEach((item)=> {
    item();
})
  },
   beforeRouteLeave(to, from, next) {
        // 设置下一个路由的 meta
        to.meta.keepAlive = true; // C 跳转到 A 时让 A 不缓存，即刷新
        next();
    },
  methods:{
   goIntoPage(pathItem){
     this.$router.push({name:pathItem.name,query:pathItem.query})
   },
   bbao(){
     var arr = [];
    for(var i = 0;i<3;i++){
      console.log('val',i);
        arr.push(()=> {
            console.log(i);
        })
    }
    return arr
   }
   
  },
  mounted(){
  
  },


}

</script>
