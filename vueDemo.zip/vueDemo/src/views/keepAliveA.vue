<template>
  <div class="yb-wrapper">
    {{keyValue}}
    <input class="yb-input" type="text" >
    <span @click="goBack">返回</span>
  </div>
</template>
<script>
export default{
  data(){
    return{
      keyValue:'keepAlive test'
    }

  },
  created(){},
  methods:{
    goBack(){
      this.$router.push({name:'keyBoard',query:{payPwdProcFlag:'VERIFYPWD'}})
    },
   
  },
   beforeRouteLeave(to, from, next) {
         // 设置下一个路由的 meta
          console.log('刷新',to)
        to.meta.keepAlive = true;  // B 跳转到 A 时，让 A 缓存，即不刷新
        next();
    },
  mounted(){
    console.log('刷新',)
  },
}

</script>
