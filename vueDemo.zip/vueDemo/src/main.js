
import Vue from 'vue'
import App from './App'
import router from './router'
import '@/assets/css/goble.css'
import '@/assets/css/common.css'
import '@/assets/css/keyCommon.css'
import 'mint-ui/lib/style.css'
import mixin from './api/mixin';
import {store} from './store/store';
import {ajax} from './api/ajax';
Vue.config.productionTip = false
import {hrt} from './api/hrtBridge';
//原生jsbridge全局变量
window.hrt = hrt
import {MessageBox,Toast, Picker,Indicator,Range,Popup} from 'mint-ui';
Vue.component(MessageBox.name, MessageBox);
Vue.component(Range.name, Range);
Vue.component(Popup.name, Popup);
Vue.component(Picker.name, Picker);
Vue.mixin(mixin);//挂载公共方法
//开发工具
if (process.env.NODE_ENV === 'dev' || process.env.NODE_ENV === 'sit' || process.env.NODE_ENV === 'uat') {
  var VConsole = require('vconsole');
  var vConsole = new VConsole();
}

/*new vue*/
new Vue({
  el: '#app',
  store,
  router,
  components: { App },
  template: '<App/>',
  beforeCreate() {
    /**
     * rem自适应布局
     * 以设计稿宽度1080为基础，1rem=100px，如标注图上文字大小为140px，css设置文字大小为1.4rem即可
     */
    (function (doc, win) {
      let docEl = doc.documentElement;
      let resizeEvt = 'orientationchange' in window ? 'orientationchange' : 'resize';
      let recalc = function () {
        let clientWidth = docEl.clientWidth;
        if (!clientWidth) return;
         if (clientWidth<450) {
            docEl.style.fontSize = 100 * (clientWidth / 720) + 'px';
         }
         else{
             docEl.style.fontSize = 90 * (450 / 720) + 'px';
         }
      };

      if (!doc.addEventListener) return;
      win.addEventListener(resizeEvt, recalc, false);
      doc.addEventListener('DOMContentLoaded', recalc, false);
      recalc();

      doc.body.classList.add('mint-custom');
    })(document, window);
  },
})

window.G = {
  source: getURLParam('source'),
  setDocumentTitle (title) {
    document.title = title;
    if (navigator.userAgent.match(/iphone|ipad/i) && navigator.userAgent.match(/MicroMessenger/)) {
      var iframe = document.createElement('iframe');
      iframe.style.display = 'none';
      iframe.src = '//cloud.huaruntong.cn/web/activity/logo/hrt.png';
      iframe.onload = function () {
        setTimeout(function () {
          iframe.onload = null;
          iframe.remove();
        }, 0);
      };
      document.body.appendChild(iframe);
    }
  }
};
