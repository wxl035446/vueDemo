<template>
  <div id="app">
    <loading v-show="loadingShow"></loading>
    <router-view/>
  </div>
</template>

<script>
import loading from './components/loading';
export default {
  name: 'App',
  components: {
    loading
  },
  computed: {
    loadingShow() {
      return this.$store.state.loadingShow;
    },
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, PingFangSC-Regular, Arial, sans-serif, "Microsoft Yahei";
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  position: absolute;
  top:0px;
  left:0px;
  right: 0px;
  width: 100%;
  height: 100%;
  color: #333;
  background-color: #f5f5f5;
}
</style>
