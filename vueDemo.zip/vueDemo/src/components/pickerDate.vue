/*
* picker date
* Created with wxl.
* Date: 2017/10/16
**/
<style lang="less" scoped>
    .ln-wrapper{
        .ln-itemLine{
            position: relative;
            background: #fff;
           .ln-label{
               position: absolute;
               left:0.5rem;
               top:50%;
               min-width:1.6rem;
               height:0.6rem;
               line-height:0.6rem;
               display: inline-block;
               transform:translate(0,-50%);
            }
            .ln-item{
                padding:0.4rem 1.07rem 0.3rem 1.9rem;
                border-bottom:1px solid #e9e9e9 ;
                .ln-input{
                    display: block;
                    width:100% ;
                    border:none;
                    height:0.6rem;
                    line-height: 0.6rem ;
                    padding-left: 0.98rem;
                }
                .ln-span{
                    display: inline-block;
                    height: 0.6rem ;
                    line-height:0.6rem ;
                }
            }
          .ln-tb{
            padding:0.4rem 0.47rem 0.4rem 2.35rem;
          }
            .ln-arrow{
                position:absolute;
                top:50%;
                right:0.47rem;
                width:0.3rem;
                height:0.51rem;
                transform:translate(0,-50%);
                background: url(../assets/img/next.png);
                background-size: 100% 100%;
            }
        }

    }
</style>

<template>

    <div>
    <div class="ln-itemLine ln-padl50 " @click.stop="popupVisible=true">
        <label class="ln-label ln-ft42 ">{{leftText}}</label>
        <div class="ln-item ln-tb"><input class="ln-input ln-al ln-ft42"  v-model="pickerValue" readonly="readonly" :placeholder="holdertip"/></div>
       <!-- <i class="ln-arrow"></i>-->
    </div>

    <mt-popup class="popup_picker popup_width" v-model="popupVisible" position="bottom" style="width:100% ">
            <mt-picker :slots="dateList" valueKey="name" :showToolbar="true" :visibleItemCount="pickerCount" @change="onDateValues">
                <slot>
                    <div>
                        <a href="javascript:void(0);" class="ln-fl pick_btn" @click.stop="closePicker">取消</a>
                        <a href="javascript:void(0);" class="ln-fr pick_btn" @click.stop="surePicker">确认</a>
                    </div>
                </slot>
            </mt-picker>
        </mt-popup>
    </div>
</template>

<script>
  export default {
    props: {
      leftText: String,
      holdertip:String,
      bankDate:{
        type:String,
        default:"",
      },
      pickerCountNum:String,
    },
    data(){
      return{
        pickerValue:'',
        totleValue:'',
        defaultIndex:'',
        obj:{},
        popupVisible:false,
        pickerCount:parseInt(this.pickerCountNum),
        yearList:[],
        curNUm:0,
        dateList:[
          {
          flex: 1,
          values: ['1月', '2月','3月','4月','5月','6月','7月','8月','9月','10月','11月','12月'],
          className: 'slot1',
          },{
            divider: true,
            content: '',
            className: 'slot2'
          }, {
            flex: 1,
            values: [],
            className: 'slot3',
            textAlign: 'left',
          }
        ],
      }
    },
    methods: {
      // Picker
      openPicker() {
        // 通过最大最小值计算年份
        let minNum=2017;
        let maxNum=2100;
        for(let i=1;i<(maxNum-minNum);i++){
          this.curNum=(parseInt(minNum)+i)+'年';
           this.yearList.push(this.curNum);
        }
        this.dateList[2].values=this.yearList;
      },
      onDateValues(picker, values){
        if(!values[0]){
          return;
        }
        if(!values[1]){
          return;
        }
        var month=values[0].substring(0,values[0].length-1);
        if(month<10){
          month='0'+month;
        }else{
          month=month
        }
        this.totleValue= month+ " / " + values[1].substring(2,values[1].length-1);
      },
      // 关闭picker
      closePicker() {
        this.popupVisible = false
      },
      //确认 picker
      surePicker(){
        this.pickerValue=this.totleValue;
        this.$emit('input',this.pickerValue);
        this.popupVisible = false;
      }
    },
    created(){
      if(this.bankDate){
        this.pickerValue= this.bankDate;
      }
      this.openPicker();
    },
  }
</script>
