<template>
  <div class="loading-box">
    <div class="inner">
      <div class="loading"></div>
      <span>加载中...</span>
    </div>
  </div>
</template>

<script>
  export default {
    data: function() {
      return {
      }
    },
    props:{
      text: String
    },
    methods: {
    }
  }
</script>

<style scoped>
  * {
    margin: 0;
    padding: 0;
  }
  .loading-box {
    width: 3.4rem;
    height: 3.4rem;
    margin: auto;
    right: 0;
    left: 0;
    top: 0;
    bottom: 0;
    font-size: 0.36rem;
    background: rgba(0, 0, 0, 0.4);
    border-radius: 0.3rem;
    color: #fff;
    text-align: center;
    position: absolute;
    z-index: 100;
  }
  .inner {
    padding-top: 0.8rem;
    padding-left: 1.15rem;
  }
  .inner span {
    position: relative;
    left: -0.4rem;
  }
  .loading {
    width: 1rem;
    height: 1rem;
    margin-left: 0.08rem;
    margin-bottom: 0.36rem;
    border-radius: 50%;
    background: url("../assets/img/loading.png");
    background-size: cover;
    animation: load 1s linear infinite;
  }
  @keyframes load{
    from {
      -webkit-transform: rotate(0deg);
    }
    to {
      -webkit-transform: rotate(360deg);
    }
  }
  @-webkit-keyframes load {
    from {
      -webkit-transform: rotate(0deg);
    }
    to {
      -webkit-transform: rotate(360deg);
    }
  }
  @-moz-keyframes load {
    from {
      -moz-transform: rotate(0deg);
    }
    to {
      -moz-transform: rotate(360deg);
    }
  }
  @-o-keyframes load {
    from {
      -o-transform: rotate(0deg);
    }
    to {
      -o-transform: rotate(360deg);
    }
  }
</style>
