<template>
  <div class="verify_code">
      <!-- 验证码 -->
      <mt-popup v-model="verifyCodeShow" :closeOnClickModal="false" popup-transition="popup-fade">
        
        <p>本次操作需要短信确认，验证码已发送至手机：150****9876，请按时操作</p>    
        <div class="code_num clearfix">
            <input type="text" placeholder="请输入验证码">
            <span v-if="count_down_show" class="disabled_btn">获取验证码({{time}}s)</span>
            <span v-else class="btn" @click="get_verify_code">获取验证码</span>
        </div>    
        <p class="not_get_code" @click="view_faq">收不到验证码？</p>
        <div class="line"></div>
        <div class="footer_btns">
            <span class="cancel" @click="verify_code_hide">取消</span>
            <span class="split_line"></span>
            <span @click="submit_code">确定</span>
        </div>
    </mt-popup>
    <!-- 查看收不到验证码原因 -->
    <mt-popup v-model="popupVisible" class="faq_modal" popup-transition="popup-fade">
        <h4 class="modal_title">收不到验证码</h4>
        <div class="text">
            <p>验证码发送至您的银行预留手机号</p>
            <p>
                1、请确认当前是否使用银行预留的手机号码 
            </p>
            <p>
                2、请检查短信是否被手机安全软件拦截 
            </p>
            <p>
                3、若预留号码已停用，请联系银行客服咨询 
            </p>
            <p>
                4、获取更多帮助，请拨打客服电话xxxxx
            </p>
        </div>
        <div class="line"></div>
        <div class="footer_btns">
            <span class="cancel" @click="popupVisible = false">确定</span>
        </div>
    </mt-popup>
  </div>
</template>

<script>
export default {
    data(){
        return{
            show: false,
            popupVisible: false,
            time: 10,
            interval:'',
            count_down_show: false
        }
    },
    props:{
        verifyCodeShow: Boolean
    },
    mounted() {
      this.show = this.verifyCodeShow;
      this.count_down_show = this.show;
    },
    watch: {
      verifyCodeShow(newVal, oldVal) {
        var me = this;
        me.show = newVal;
        me.count_down_show = me.show;
        me.time = 10;
        if(me.show){
            this.timer();
        }
      }
    },
    methods: {
        submit_code(){
            this.$emit("hideVerifyCode", false);
            alert('验证成功');
        },
        verify_code_hide(){
            this.$emit('hideVerifyCode', false);
        },
        view_faq(){
            this.$emit("hideVerifyCode", false);
            this.popupVisible = true;
        },
        timer(){
            var me = this;
            me.time = 10;
            clearInterval(me.interval);
            me.interval = setInterval(function(){
                if((me.time --) <= 1){
                    me.count_down_show = false;
                    clearInterval(me.interval);
                }
            },1000)
        },
        get_verify_code(){
            this.count_down_show = true;
            this.timer();
        }
    }
    
}
</script>

<style lang="scss" scoped>
.verify_code{
    .mint-popup{
        width:10rem;
        border-radius: 0.2rem;
        padding: 0.6rem 0.8rem 0 0.8rem;
        box-sizing: border-box;
        font-size: 0.42rem;
    }
    .faq_modal{
        div.text{
            text-align: left;
            p{
                height: 0.8rem;
                line-height: 0.8rem;
            }
            
        }
    }
    .code_num{
        margin: 0.7rem 0 0.4rem 0;
        font-size: 0.36rem;
        input{
            width: 5rem;
            box-sizing: border-box;
            height: 1rem;
            line-height: 1rem;
            border-radius: 0.1rem 0 0 0.1rem;
            outline-style: none;
            border: 0.02rem solid #D7D7D7;
            border-right: none; 
            float: left;   
            font-size: 0.36rem; 
            padding: 0 0 0 0.2rem;
        }
        span.btn,.disabled_btn{
            width: 3.4rem;
            padding: 0 0.2rem;
            box-sizing: border-box;
            height: 1.01rem;
            line-height: 1.01rem;
            border-radius: 0 0.1rem 0.1rem 0;
            background: linear-gradient(to right,#FFAC2C,#FFCC31);
            opacity: 0.5;
            float: left;
            color: #fff;
        }
        .btn:hover{
            opacity: 1;
        }
    }
    .not_get_code{
        text-align: right;
        color:#FFB42E;
        font-size: 0.36rem;
    }
    .line{
        position: absolute;
        width: 100%;
        height: 0.03rem;
        left: 0;
        background: #D7D7D7;
        bottom: 1.42rem;
    }
    .footer_btns{
        margin: 0.4rem 0 0 0;
        width: 100%;
        height: 1.42rem;
        line-height: 1.42rem;
        text-align: center;
        span{
            display: inline-block;
            width: 48%;
            font-size: 0.45rem;
        }
        .cancel{
            color:#666;
        }
        .split_line{
            height: 0.5rem;
            width: 0.03rem;
            background: #D7D7D7;
            vertical-align: sub;
        }
    }

    .modal_title{
        font-size: 0.52rem;
        padding: 0;
        margin: 0 0 0.8rem 0;
    }
    
}
</style>

