<template>
  <div class="personal_title">
    <div class="segment"></div>
    <ul class="steps_title clearfix">
        <li>
          <div class="title_icon">
            <div class="title_round">
              <span v-if="activeStep == 1" class="big_round_icon"></span>
              <span class="round_icon" :class="{step_active: activeStep == 1,step_finished: activeStep > 1}"></span>
            </div>
            <span class="line" :class="{step_finished: activeStep > 1}"> </span>
          </div>
          <div :class="{step_active_text: activeStep == 1,step_finished_text: activeStep > 1}">实名认证</div>
        </li>
        <li>
          <div class="title_icon">
            <div class="title_round">
              <span v-if="activeStep == 2" class="big_round_icon"></span>
              <span class="round_icon" :class="{step_active: activeStep == 2,step_finished: activeStep > 2}"></span>
            </div>
            <span class="line"  :class="{step_finished: activeStep > 2}"></span>
          </div>
          <div :class="{step_active_text: activeStep == 2,step_finished_text: activeStep > 2}">个人信息</div>
        </li>
        <li>
          <div class="title_icon">
            <div class="title_round">
              <span v-if="activeStep == 3" class="big_round_icon"></span>
              <span class="round_icon" :class="{step_active: activeStep == 3}"></span>
            </div>
           
          </div>
          <div :class="{step_active_text: activeStep == 3,step_finished_text: activeStep == 3}">信用授权</div>
        </li>
      </ul>
  </div>
</template>

<script>
export default {
  data(){
    return{
      step_finished: true,  //已完成的步骤
      step_active: true,    //当前操作的步骤
    }
  },
  props:["activeStep"],
  methods: {
   
  }
}
</script>

<style lang="scss">
  .personal_title{
    background-color: #fff;
  }
  .segment{
    width: 100%;
    height: 0.02rem;
    background-color:#D7D7D7; 
  }
  ul.steps_title{
    padding: 0.65rem .14rem;
    margin:  0;
    li{
      width: 33.3%;
      float: left;
      font-size: 0.42rem;
      position: relative;
    }
   
    .big_round_icon{
      position: absolute;
      left: 50%;
      top: 50%;
      margin: -0.22rem 0 0 -0.22rem; 
     
      background: #FEB983;
      width: 0.46rem;
      height: 0.46rem;
      border-radius: 50%;
      //animation: ripple 2s ease-in-out 0s infinite;
    }
    .round_icon{
      position: absolute;
      left: 50%;
      top: 50%;
      margin-left: -0.16rem; 
      margin-top: -0.16rem;
      background-color: #D7D7D7;
      width: 0.34rem;
      height: 0.34rem;
      border-radius: 50%;
    }
    
    .line{
      position: absolute;
      left: 52%;
      top: 15%;
      width: 100%;
      height: 0.03rem;
      
      background-color: #D5D5D5;
    }

    .title_round{
      position: absolute;
      width: 0.44rem;
      height: 0.44rem;
      left: 50%;
      top: 0;
      margin-left: -0.22rem;
      z-index: 1;
    }
    .title_icon{
      height: 0.44rem;
      margin: 0 0 0.32rem 0;
    }
    .step_active,.step_finished{
      background-color: #FB8023;
    }
    .step_active_text,.step_finished_text{
      color: #FB8023;
    }
    
    @keyframes ripple {
      0% {
        opacity:0.35;
        left: 75%;
        top: 75%;
        margin: -0.22rem 0 0 -0.22rem; 
        width: 0.25rem;
        height: 0.25rem;
      }
      100% {
        left: 50%;
        top: 50%;
        margin: -0.22rem 0 0 -0.22rem; 
        opacity: 1;
        width:0.44rem;
        height: 0.44rem;
      }
      }

    
  }
  
</style>

