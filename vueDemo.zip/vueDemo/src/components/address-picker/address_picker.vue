<template>
  <div class="address">
    <!--地址选择组件-->
    <mt-popup v-model="show" position="bottom" :closeOnClickModal="closeOnClickModal">
      <section style="width:100%; height: 100%;">
        <!-- <div class="padding">
          <span @click="hidePicker">
            <img src="../../assets/icon/close.png" alt="">
          </span>
          <span @click="saveAddress" class="float-right">完成</span>
        </div> -->
         <p class="modal_title">
          <span>紧急联系人</span>
          <span @click="hidePicker">
            <img src="../../assets/icon/close.png" alt="">
          </span>
        </p>
        
        <mt-picker :slots="slots" value-key="name" @change="onValuesChange"></mt-picker> 
      </section>
    </mt-popup>
  </div>
</template>

<script>
  import address from './address.js'
  
  export default {
    name: 'ads',
    props: {
      showAddressPicker: Boolean,
      init: String
    },
    
    mounted() {
      let vm = this
      vm.show = vm.showAddressPicker
    },
    data() {
      return {
        slots: [
            {
              flex: 1,
              values: address,
              defaultIndex:10,
              className: 'slot1',
              textAlign: 'right'
            },
            {
              flex: 1,
              values: address[0].childs,
              defaultIndex:0,
              className: 'slot2',
              textAlign: 'left'
            },
            {
              flex: 1,
              values: address[0].childs[0].childs,
              defaultIndex:0,
              className: 'slot3',
              textAlign: 'left'
            }
        ],
        addressValue: '',
        disableClear: true,
        show: true,
        closeOnClickModal: true
      }
    },
    watch: {
      showAddressPicker(old, val) {
        this.show = !val
      },
    },
    methods: {
      saveAddress() { //保存所选地区
        let vm = this
        vm.show = false
        vm.$emit('save-address', vm.addressValue);
      },
      hidePicker() { // 取消选择
        this.$emit('hide-picker', false);
      },
      onValuesChange(picker, values) {
        if(!values[0]){
            this.$nextTick(()=>{
                if(this.myAdress){
                      // 赋默认值
                }else{
                      picker.setValues([address[0],address[0].childs[0],address[0].childs[0].childs[0]])
                }
            });
        }else{
            picker.setSlotValues(1, values[0].childs);
            let town = [];
            if(values[1]){
              town = values[1].childs;
            }
            picker.setSlotValues(2,town);
        }
      }
    
    }
  }

</script>

<style scoped>
  
  .footer-btn {
    box-sizing: border-box;
    position: fixed;
    width: 100%;
    z-index: 2;
    left: 0;
    bottom: 3rem;
  }
  
  .input {
    border: none;
  }
  
  .padding {
    padding: 15px;
  }
  
  .float-right {
    float: right;
  }

</style>
