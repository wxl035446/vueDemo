const address = [
  {
    "code": "001",
    "name": "河南省",
    "childs": [
      {
        "code": "001-1",
        "name": "郑州市",
        "childs": [
          {
            "code": "001-1-1",
            "name": "中原区"
          },
          {
            "code": "001-1-2",
            "name": "二七区"
          }
        ]
      },
      {
        "code": "001-2",
        "name": "许昌市",
        "childs": [
          {
            "code": "001-2-1",
            "name": "禹州市"
          },
          {
            "code": "001-2-2",
            "name": "长葛市"
          }
        ]
      }
    ]
  },
  {
    "code": "002",
    "name": "北京",
    "childs": [
      {
        "code": "002-1",
        "name": "北京市",
        "childs": [
          {
            "code": "002-1-1",
            "name": "海淀区"
          },
          {
            "code": "002-1-2",
            "name": "朝阳区"
          }
        ]
      }
    ]
  },
  {
    "code": "003",
    "name": "广东省",
    "childs": [
      {
        "code": "003-1",
        "name": "深圳市",
        "childs": [
          {
            "code": "003-1-1",
            "name": "南山区"
          },
          {
            "code": "003-1-2",
            "name": "福田区"
          }
        ]
      },
      {
        "code": "003-2",
        "name": "广州市",
        "childs": [
          {
            "code": "003-2-1",
            "name": "AAAA"
          },
          {
            "code": "003-2-2",
            "name": "BBBB"
          }
        ]
      }
    ]
  }
];
export default address
