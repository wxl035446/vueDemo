<template>
  <div class="more_operate">
    <span></span>
    <span></span>
    <span></span>
    <div v-if="show" class="items_nr">
      <b class="arrow"></b>
      <ul class="more_operate_item">
          <li @click="view_history">历史记录</li>
          <li @click="band_cards_manage">银行卡管理</li>
      </ul>
    </div>
    <div @click.stop="close_modal" v-if="show" class="more_oprate_modal"></div>
  </div>
</template>

<script>
export default {
  data(){
    return{
      show: false
    }
  },
  props:{
    modalShow: Boolean
  },
  mounted() {
    this.show = this.modalShow;
  },
  watch: {
    modalShow: function(newVal, oldVal){
      this.show = newVal;
    }
  },
  methods: {
    close_modal(){
      this.show = false;
      this.$emit('hideModal', false);
    },
    view_history(){
      this.$router.push({name: 'loanList'});
    },
    band_cards_manage(){
      this.$router.push({name: 'bandCardsList'});
    }
  }
}
</script>

<style lang="scss" scoped>
.more_operate{
  float: right;
  margin: 0.6rem 0.5rem 0 0;
  position: relative;
  span{
    float: left;
    width: 0.2rem;
    height: 0.2rem;
    border-radius: 50%;
    background: #fff;
    margin-right: 0.1rem;
  }
}
.more_oprate_modal{
  position: fixed;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  opacity: 0.5;
  background: #000;
  z-index: 10;
  transition: fade 2s ease-in-out;
}

@keyframes fade {
  0%{ opacity: 0 }
  100% { opacity: 1}
}
.items_nr{
  position: absolute;
  right: 0;
  top: 0.2rem;
  width: 1.4rem;
  z-index: 100;

  .more_operate_item{
    position: absolute;
    right: 0;
    top: 0.5rem;
    width: 3.5rem;
    height: 2.2rem;
    background: #fff;
    border-radius: 0.1rem;
    padding: 0 0.16rem;
    box-sizing: border-box;
    font-size: 0.39rem;
    color:#333;
    text-align: left;
    
    li{
      padding: 0 0.3rem;
      height: 1.05rem;
      line-height: 1.05rem;
      border-bottom: 0.01rem solid #D1D1D1;
    }
    li:last-child{
      border:none;
    }
    
  }
  .arrow{
    position: absolute;
    top: 0.02rem;
    width:0; 
    height:0; 
    border:0.28rem solid; 
    border-color: transparent transparent #fff transparent;
    left: 50%;
    margin-left: -0.05rem;

  }
}
        
</style>